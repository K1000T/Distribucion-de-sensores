class Aspersor:
    def activarAspersor(self):
        print("Aspersor activado")
    
        

   
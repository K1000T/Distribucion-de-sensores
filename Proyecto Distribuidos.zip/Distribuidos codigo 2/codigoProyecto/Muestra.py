class Muestra:
    def __init__(self):
        self.tipo
        self.valor
        self.tiempo
        
    
    def get_tipo(self):
        return self.tipo
    
    def get_valor(self):
        return self.valor
    
    def get_tiempo(self):
        return self.tiempo
    
    def set_tipo(self, tipo):
        self.tipo = tipo
    
    def set_valor(self, valor):
        self.valor = valor
    
    def set_tiempo(self, tiempo):
        self.tiempo = tiempo